package project2.util;

class TAInfo{
public static void infoTA(Connection conn)
{
		try
		{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter classid: ");
		String classid = br.readLine();
		
		CallableStatement stmt = conn.prepareCall("begin student_registration.ta_info(?,?,?); end;");
		stmt.setString(1,classid);
		stmt.registerOutParameter(2,java.sql.Types.VARCHAR);
		stmt.registerOutParameter(3,OracleTypes.CURSOR);
		stmt.execute();
		ResultSet rs = null;
		try{
        	rs = ((OracleCallableStatement)stmt).getCursor(3);
 	 	}
	  	catch(Exception ex){
	       	String err_msg = ((OracleCallableStatement)stmt).getString(2);
	       	System.out.println(err_msg);
	   	}
	   	if(rs != null){
	       	while (rs.next()) {
	          	System.out.println(rs.getString(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3));
	       		}
	   		}
		}
	
		catch(Exception e)
		{
		e.printStackTrace();
		System.exit(1);
		}
	}
}
