package project2.util;

class Prerequisites{
	public static void infoPrerequisites(Connection conn) {
		try
		{	
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter Dept Code: ");
			String dept_code = br.readLine();
			System.out.println("Enter Course No: ");
			String course_no = br.readLine();
                		
			CallableStatement stmt = conn.prepareCall("begin student_registration.get_prerequisites(?,?,?,?); end;");
			stmt.setString(1, dept_code);
			stmt.setInt(2, Integer.parseInt(course_no));
     		stmt.registerOutParameter(3,java.sql.Types.VARCHAR);
			stmt.registerOutParameter(4,OracleTypes.CURSOR);
                             
			stmt.execute();

			ResultSet rs = null;                            
  		        try{
  		        	rs = ((OracleCallableStatement)stmt).getCursor(4);
  		        }
  		        catch(Exception ex){
  		        	String err_msg = ((OracleCallableStatement)stmt).getString(3);
  		        	System.out.println(err_msg);
  		        }

  		      	if(rs != null){
  		    		System.out.println("\n\nCOURSE");
  		        	while (rs.next()) {
  		          		System.out.println(rs.getString(1) + rs.getInt(2)); 
  		          		}
  		      		}
  		      	
                String TruncateTable = "Truncate table temp_prerequisites";	
     			Statement stmt1 = conn.createStatement();
     			stmt1.executeQuery(TruncateTable);
                       
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(1);
		}
	}
}
