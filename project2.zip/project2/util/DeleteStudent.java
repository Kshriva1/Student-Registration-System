package project2.util;

class DeleteStudent{
	public static void deleteStudent(Connection conn) {
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Student Bno: ");
			String Bno = br.readLine();
			
			CallableStatement stmt = conn.prepareCall("BEGIN student_registration.del_student(?,?); END;");
			stmt.setString(1,Bno);
			stmt.registerOutParameter(2, java.sql.Types.VARCHAR);
			stmt.execute();
			
			String err_msg = ((OracleCallableStatement)stmt).getString(2);
		      	
			if(err_msg == null){
		    	  System.out.println("\nStudent deleted successfully.");
		    }
		    else{
                   System.out.println(err_msg);

		    }
          	stmt.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			System.exit(1);
		}
	}
}
