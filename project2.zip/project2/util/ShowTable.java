package project2.util;

class ShowTable{
  	public static void showTableInfo(int choice, Connection conn)
	{
		switch(choice)
		{
			case 1:
			{
				try
				{
		            CallableStatement stmt = conn.prepareCall("BEGIN student_registration.show_students(?); END;");
			        stmt.registerOutParameter(1, OracleTypes.CURSOR);
			        stmt.execute();
			        ResultSet rs = ((OracleCallableStatement)stmt).getCursor(1);
				    
			        while (rs.next())
			        {
				      	System.out.println(rs.getString(1) 
							+"\t\t\t"+rs.getString(2)
							+"\t\t\t"+rs.getString(3)
							+"\t\t\t"+rs.getString(4)
							+"\t\t\t"+rs.getDouble(5)
							+"\t\t"+rs.getString(6)
							+"\t\t"+rs.getString(7).substring(0,11)
							+"\t\t\t"+rs.getString(8));
				      }
			        rs.close();
				}
				catch (Exception e)
				{
					e.printStackTrace();
					System.exit(1);
				}
				break;
			}
			
			case 2:
			{
				try
				{
	                CallableStatement stmt = conn.prepareCall("BEGIN student_registration.show_courses(?); END;");
                    stmt.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
				    stmt.execute();
				    ResultSet rs = ((OracleCallableStatement)stmt).getCursor(1);
				    while (rs.next())
				    {
				 	    System.out.println(rs.getString(1)+"\t"
							+rs.getInt(2)+"\t"
							+rs.getString(3));
				   	}
                    rs.close(); 
				}

				catch (Exception e)
				{
					e.printStackTrace();
					System.exit(1);
				}
				break;
			}

      		case 3:
      		{
        		try
        		{
          			CallableStatement stmt = conn.prepareCall("BEGIN student_registration.show_TAs(?); END;");
          			stmt.registerOutParameter(1, OracleTypes.CURSOR);
            		stmt.execute();
            		ResultSet rs = ((OracleCallableStatement)stmt).getCursor(1);

            		while (rs.next())
            		{
            			System.out.println(rs.getString(1) + "\t" 
							+ rs.getString(2) + "\t" 
							+ rs.getString(3));
            		}
                    rs.close();
        		}
        		
        		catch (Exception e)
        		{
          			e.printStackTrace();
          			System.exit(1);
        		}
        		break;
      		}

			case 4:
			{
				try
				{
			        CallableStatement stmt = conn.prepareCall("BEGIN student_registration.show_classes(?); END;");
			        stmt.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
			        stmt.execute();
			        ResultSet rs = ((OracleCallableStatement)stmt).getCursor(1);
			        while (rs.next())
			        {
			            System.out.println(rs.getString(1)+"\t" 
							+ rs.getString(2)+"\t" 
							+ rs.getInt(3)+"\t" 
							+ rs.getInt(4)+"\t" 
							+ rs.getInt(5)+"\t" 
							+ rs.getString(6)+"\t" 
							+ rs.getInt(7)+"\t"
						 	+ rs.getInt(8)+"\t"
							+ rs.getString(9)+"\t" 
							+ rs.getString(10));
				    }
				    rs.close();
				}
				catch (Exception e)
				{
                    e.printStackTrace();
					System.exit(1);
				}
				break;
			}

  			case 5:
      		{
        		try
        		{
          			CallableStatement stmt = conn.prepareCall("BEGIN student_registration.show_enrollments(?); END;");
          			stmt.registerOutParameter(1, OracleTypes.CURSOR);
            		stmt.execute();
            		ResultSet rs = ((OracleCallableStatement)stmt).getCursor(1);
            		while (rs.next())
            		{
            			System.out.println(rs.getString(1)+"\t" 
							+ rs.getString(2)+"\t" 
							+ rs.getString(3));
              		}
              		rs.close();
        		}
        		catch (Exception e)
        		{
                    e.printStackTrace();
          			System.exit(1);
        		}
        		break;
      		}

			case 6:
			{
				try
				{
				    CallableStatement stmt = conn.prepareCall("BEGIN student_registration.show_prerequisites(?); END;");
				    stmt.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
				    stmt.execute();
				    ResultSet rs = ((OracleCallableStatement)stmt).getCursor(1);
				    while (rs.next())
				    {
					    System.out.println(rs.getString(1)+"\t" 
							+ rs.getInt(2)+"\t"
							+ rs.getString(3)+"\t"
							+ rs.getInt(4));
				    }
				    rs.close();
				}
				catch (Exception e)
				{
                    e.printStackTrace();
					System.exit(1);
				}
				break;
			}

			case 7:
			{
				try
				{
					CallableStatement stmt = conn.prepareCall("BEGIN student_registration.show_logs(?); END;");
					stmt.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
				    stmt.execute();
				    ResultSet rs = ((OracleCallableStatement)stmt).getCursor(1);
				    while (rs.next())
				    {
				    	System.out.println(rs.getInt(1)+"\t"
							+ rs.getString(2)+"\t"
							+ rs.getString(3)+"\t"  
							+ rs.getString(4)+"\t" 
							+ rs.getString(5)+"\t"
							+ rs.getString(6));
				    }
				    rs.close();
				}
				catch (Exception e)
				{   
					e.printStackTrace();
					System.exit(1);
				}
				break;
			}
		}
	}
}
