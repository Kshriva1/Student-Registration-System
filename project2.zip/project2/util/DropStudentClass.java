package project2.util;

class DropStudentClass{
	public static void dropStudentClass(Connection conn) {
 		try
 		{
 			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
 			System.out.println("Student B#: ");
 			String Bno = br.readLine();
 			System.out.println("Enter Class ID: ");
 			String classid = br.readLine();
 			
			CallableStatement stmt = conn.prepareCall("BEGIN student_registration.drop_student(?,?,?); END;");
 			stmt.setString(1,Bno);
 			stmt.setString(2,classid);
 			stmt.registerOutParameter(3, java.sql.Types.VARCHAR);
 			stmt.execute();

      			String err_msg = ((OracleCallableStatement)stmt).getString(3);
		        if(err_msg == null){
		    	  System.out.println("\nStudent dropped from the course successfully.");
		        }
		        else{
		    	  System.out.println(err_msg);
		        }

  			stmt.close();
 		}
 		catch (Exception e)
 		{
 			e.printStackTrace();
 			System.exit(1);
 		}
 	}
}
