package project2.driver;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.*;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;

import project2.util.*;

public class Driver4 {
  	public static void main(String args[]) throws SQLException {
    	try {
      		OracleDataSource ds = new oracle.jdbc.pool.OracleDataSource();
      		ds.setURL("jdbc:oracle:thin:@castor.cc.binghamton.edu:1521:ACAD111");
      		Connection conn = ds.getConnection("vsaxena1","varun");
      
		    while(true)
      		{

				System.out.println();
				System.out.println("*****Main Menu*****");

				System.out.println("1.View Table data");
				System.out.println("2.View TA Information");
				System.out.println("3.View Prerequisites Information");
				System.out.println("4.Enroll a Student in Class");
				System.out.println("5.Drop a Student from Class");
				System.out.println("6.Delete a Student");
				System.out.println("7.Exit");
        		int n = 0;
        		Scanner sc = new Scanner(System.in);
        		System.out.println("Please select an option from the above : ");
        		n = sc.nextInt();

        		switch(n)
        		{
         			case 1:
          			{
          				ShowTable showTable = new ShowTable();

            			System.out.println();
						System.out.println("***Select Table***");
						System.out.println("1.Students\n"
							+ "2.Courses\n"
							+ "3.TAs\n"
							+ "4.Classes\n"
							+ "5.Enrollments\n"
							+ "6.Prerequisites\n"
				            + "7.Logs\n");
            			int m = 0;
            			try {
			    			BufferedReader inputReader = new BufferedReader(new InputStreamReader(System.in));
			    			do
			    			{
				    			System.out.println("Enter Choice From Above Options");
				    			m = Integer.parseInt(inputReader.readLine());
			    			}
			    			while(m < 1 || m > 7);
	        			}
	        			catch (Exception e) {
		      				e.printStackTrace();
		    				System.exit(1);
            			}
            			showTable.showTableInfo(m,conn);
		    			break;
	  	  			}

          			case 2:
          			{
          				TAInfo ta = new TAInfo();
        	  			ta.infoTA(conn);
        	  			break;
          			}

          			case 3:
          			{
          				Prerequisites prerequisite = new Prerequisites();
        				prerequisite.infoPrerequisites(conn);
        	  			break;
          			}

          			case 4:
          			{
          				Enrollments enroll = new Enrollments();
        				enroll.enrollStudentClass(conn);
        	  			break;
          			}

          			case 5:
          			{
          				DropStudentClass drop = new DropStudentClass();
        	  			drop.dropStudentClass(conn);
        	  			break;
          			}

          			case 6:
          			{
          	  			DeleteStudent delStudent = new DeleteStudent();
        	  			delStudent.deleteStudent(conn);
        	  			break;
          			}

          			case 7:
          			{
        	  			System.exit(1);;
        	  			break;
          			}
        		}
    		}
    	}

    	catch (Exception e) {
    		System.out.println("Connection not Established. Try Again");
    		System.exit(1);
    	}
  	}
}
